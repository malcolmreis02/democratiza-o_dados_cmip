import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
import pandas as pd
import regionmask
import geopandas as gpd
from joblib import Parallel, delayed
import xarray as xr
import time
import os
import nc_time_axis
np.seterr(all="ignore")

inicio_execucao = time.time()

#### FUNCOES

def coletando_dados(n, mask, lon, lat):
    # print(n)
    delta_lon = 0
    lon_municipios, lat_municipios = municipios_centroid_x[n], municipios_centroid_y[n]
    sel_mask = mask.where(mask == n).values
    id_lon = lon[np.where(~np.all(np.isnan(sel_mask), axis=0))]
    if len(id_lon) >= 1:
        id_lat = lat[np.where(~np.all(np.isnan(sel_mask), axis=1))]
        out_sel = var.sel(lat=slice(id_lat[0], id_lat[-1]),
                                               lon=slice(id_lon[0], id_lon[-1])).compute().where(mask == n)

        out_sel = np.nanmean(out_sel.values, axis=(1, 2))

    else:
        out_sel = var.sel(lat=lat_municipios,
                                               lon=lon_municipios,
                                               method='nearest')

    while np.isnan(out_sel[0]):
        print(n)
        out_sel = var.sel(lat=lat_municipios,
                lon=lon_municipios + delta_lon,
                method='nearest').values
        delta_lon += -0.1

    municipios_data_pandas = out_sel

    return municipios_data_pandas

### PREPARANDO A BASE CONTENDO ATRIBUTOS DO MODELO

def armazen_atributos(variavel, df):
    # Extraindo os atributos da variável
    attr = variavel.attrs
    ori_name = nvar2get
    lg_name = attr.get('long_name')
    st_name = attr.get('standard_name')
    unt = attr.get("units")

    # Adicionando os valores ao DataFrame
    df.loc[len(df)] = [ori_name, st_name, lg_name, unt]

    return df

atributos = ["original_name", "standard_name", "long_name", "units"]
df_atributos = pd.DataFrame(columns = atributos)


### SELECIONANDO O MUNICIPIO QUE VOCE QUER
#### Veja nesse link qual é o geocodigo da cidade



municipios = gpd.read_file('malha2022/Brazil_2022.shp')
municipios = municipios.filter(items=['code_mn', 'name_mn', 'abbrv_s', 'geometry'])
municipios['code_mn'] = municipios['code_mn'].astype(int)
municipios = municipios[municipios['code_mn'].isin([2611606])]
municipios.head(4)

### LISTANDO OS MODELOS QUE VOCÊ BAIXOU

arqs_nc = os.listdir("modelos_cmip")
arqs_nc

### LISTANDO OS ELEMENTOS QUE O MODELO POSSUI

elementos = [item.split("_")[0] for item in arqs_nc]
elementos

if len(set(elementos))==1:
  opcao = "um_elemento"
else:
  opcao = 'mais_de_um'

### AQUI CADA LOOP SERA O TRATAMENTO DE CADA ARQUIVO .NC

for i in range(len(arqs_nc)):
  nvar2get = elementos[i]

  # caminho dos arquivos NetCDF
  var = xr.open_dataset('modelos_cmip/{}'.format(arqs_nc[i]))[nvar2get]

  if len(var.dims) == 4 and 'lev' in var.dims:
    var = var.isel(lev=0)

  if i == 0:
    armazen_atributos(var, df_atributos)

  if i == 0:
    municipios_centroid_x = municipios.to_crs(epsg=5641).centroid.to_crs(municipios.crs).x.values
    municipios_centroid_y = municipios.to_crs(epsg=5641).centroid.to_crs(municipios.crs).y.values

    # mascara dos municípios
    municipios_mask_poly = regionmask.Regions(name="municipios_mask",
                                              numbers=list(range(len(municipios))),
                                              names=list(municipios.code_mn),
                                              # abbrevs=list(municipios.name_mn),
                                              outlines=list(municipios.geometry.values[i] for i in range(len(municipios))))

    municipios_mask_poly.overlap = False
    mask_munic = municipios_mask_poly.mask(var['lon'], var['lat'])

    lat = mask_munic.lat.values
    lon = mask_munic.lon.values
    print("Extraindo dados dos municípios")

  start = time.time()
  saida = Parallel(n_jobs=-1, verbose=4)(delayed(coletando_dados)(n, mask_munic, lon, lat)
                                        for n in range(len(municipios.code_mn)))
  print(f'tempo: {time.time() - start}')

  municipios_data = pd.DataFrame(np.empty((len(municipios.code_mn),
                                          len(var.time)), dtype="float"),
                                          columns=var.time.dt.strftime('%Y-%m-%d'),
                                          index=municipios.index)

  for n in range(len(saida)):
      municipios_data.iloc[n, :] = saida[n]

  municipios_data.set_index(municipios.index, inplace=True)
  municipios2 = pd.concat((municipios, municipios_data), axis=1).drop(columns=["geometry"])
  municipios_data.set_index(municipios2.code_mn, inplace=True)

  municipios3 = pd.melt(municipios2,
                    id_vars=['code_mn','name_mn', 'abbrv_s'], 
                    var_name='date',
                    value_name=nvar2get)

  if opcao=="um_elemento":
    if (i == 0):
      banco = municipios3
    else:
      banco2 = municipios3
      banco = pd.concat([banco, banco2], ignore_index=True).drop_duplicates(subset=["code_mn", "date", nvar2get])

    print(banco.head(3))
  else:
    if (i == 0):
      banco = municipios3
    else:
      banco2 = municipios3
      banco = banco.merge(banco2, on=["code_mn", "date", "name_mn", "abbrv_s"], how="outer")

df_atributos.to_excel("bancos_prontos/tabela_atributos.xlsx", sheet_name="atributos", index=False)
banco.to_csv("bancos_prontos/bancos_csv/poluicao_cmip.csv", index=False, encoding="utf-8")
banco.to_parquet("bancos_prontos/bancos_parquet/poluicao_cmip.parquet")



fim_execucao = time.time()
print(fim_execucao-inicio_execucao)
